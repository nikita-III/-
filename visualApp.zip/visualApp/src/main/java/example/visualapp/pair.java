/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package example.visualapp;

/**
 *
 * @author evgen
 */
public class pair {
    int mark;
    String fio;

    public pair(int mark, String fio) {
        this.mark = mark;
        this.fio = fio;
    }

    @Override
    public String toString() {
        return "pair{" + "mark=" + mark + ", fio=" + fio + '}';
    }
    
    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }

    public String getFio() {
        return fio;
    }

    public void setFio(String fio) {
        this.fio = fio;
    }
    
    
}
