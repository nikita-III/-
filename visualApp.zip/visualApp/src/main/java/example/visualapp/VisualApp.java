/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package example.visualapp;

/**
 *
 * @author evgen
 */
public class VisualApp {

    public static void main(String[] args) {
        Model m = BModel.build();
        viewPair vp = new viewPair();
        m.addObserver(vp);
        
        m.addMark(new pair(5, "Иванов"));
        m.addMark(new pair(4, "Петров"));
        pair q = new pair(2, "Студент");
        m.addMark(q);
        m.removeMark(q);
    }
}
