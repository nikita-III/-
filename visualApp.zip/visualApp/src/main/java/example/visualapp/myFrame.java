/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package example.visualapp;

import javax.swing.JFrame;

/**
 *
 * @author evgen
 */
public class myFrame {
    public static void main(String[] args) {
    // Создаем фрейм
    JFrame frame = new JFrame();
    // Задаем размер окна и положение
    frame.setSize(300, 200);
    frame.setLocation(200, 100);
    // Настройка дополнительных свойств
    frame.setTitle("Hello!");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    // Отображение окна приложения
    frame.setVisible(true);
  }

}
