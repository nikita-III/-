/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package example.visualapp;

/**
 *
 * @author evgen
 */
public class viewPair implements IObserver{

    @Override
    public void event(Model m) {
        System.out.println("Все оценки:");
        for (pair object : m) {
            System.out.println(object);
        }
    }
    
}
