/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package example.visualapp;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author evgen
 */
public class Model implements Iterable<pair>{
    ArrayList<pair> allPair = new ArrayList<>();
    ArrayList<IObserver> allObserver = new ArrayList<>();
    
    void eventCall(){
        allObserver.forEach(action->action.event(this));
    }
    
    public void addMark(pair p){
        allPair.add(p);
        eventCall();
    }
    
    public void removeMark(pair p) {
        allPair.remove(p);
        eventCall();
    }
    
    public void updateMark(pair p) {
        if(allPair.contains(p))
            eventCall();
        else
            addMark(p);
    }
    
    public void addObserver(IObserver e){
        allObserver.add(e);
        eventCall();
    }
    
    
    @Override
    public Iterator<pair> iterator() {
        return allPair.iterator();
    }
    
    
}
